Paper Pixels
------------


Enjoy my assets? Keep up to date by following me on Itch or Twitter.

https://v3x3d.itch.io/
https://twitter.com/_V3X3D

You can also support me on Patreon for just a $1 each month.
Your support helps me keep making assets and provides you with great rewards.

https://www.patreon.com/V3X3D


Cheers,
-- VEXED
